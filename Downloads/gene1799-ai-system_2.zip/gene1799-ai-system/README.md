# 🤖 GENE1799 AI System v2.0

Sistema di agenti AI auto-imparanti con supporto multi-AI per Gene1799 Art Corporation.

## ✨ Features

- **4 Agenti Specializzati Auto-Imparanti:**
  - 📈 **TradingAgent** - Analisi mercati, pattern recognition, strategie
  - 🎨 **NFTAgent** - Generazione prompt arte, metadata, curation
  - ⚙️ **WorkflowAgent** - Automazione, orchestrazione task
  - 🛡️ **SystemAgent** - Monitoraggio, self-healing, diagnostica

- **Multi-AI Provider Support:**
  - 🦙 Ollama (locale, gratuito)
  - 🟢 OpenAI (GPT-4, GPT-3.5)
  - 🟠 Anthropic (Claude)
  - ⚡ Groq (ultra-veloce)

- **Self-Learning:**
  - Memoria short-term e long-term
  - Pattern recognition automatico
  - Apprendimento da errori
  - Miglioramento continuo

## 🚀 Quick Start

### 1. Installa dipendenze
```bash
cd D:\C1799HubEnhanced\ai-integration
npm install
```

### 2. Configura AI Provider (scegli uno o più)

**Opzione A - Ollama (Consigliato - Gratuito)**
```bash
# Installa Ollama da https://ollama.ai
ollama pull llama2
ollama pull mistral  # opzionale
```

**Opzione B - API Keys**
Crea file `.env`:
```env
OPENAI_API_KEY=sk-your-key
ANTHROPIC_API_KEY=sk-ant-your-key
GROQ_API_KEY=gsk_your-key
```

### 3. Avvia il sistema
```bash
npm start
```

### 4. Apri Dashboard
Vai a: `http://localhost:3002`

## 📁 Struttura

```
gene1799-ai-system/
├── config/
│   └── ai-config.js      # Configurazione AI providers
├── providers/
│   └── AIProviderManager.js  # Gestione multi-AI
├── agents/
│   ├── SelfLearningAgent.js  # Classe base auto-imparante
│   └── SpecializedAgents.js  # Agenti specializzati
├── core/
│   ├── AgentManager.js      # Orchestratore centrale
│   └── IntegrationServer.js # Server API + WebSocket
├── dashboard/
│   └── index.html           # Dashboard controllo
└── scripts/
    ├── monitor.js           # Self-healing monitor
    └── test-agents.js       # Test suite
```

## 🔌 API Endpoints

| Endpoint | Metodo | Descrizione |
|----------|--------|-------------|
| `/integration/health` | GET | Health check |
| `/api/status` | GET | Status completo sistema |
| `/api/agents` | GET | Lista agenti |
| `/api/agents/health` | GET | Health agenti |
| `/api/agents/:name/query` | POST | Query singolo agente |
| `/api/agents/train` | POST | Training tutti agenti |
| `/api/providers` | GET | Status AI providers |
| `/api/trading/analyze` | POST | Analisi trading |
| `/api/nft/generate-prompt` | POST | Genera prompt NFT |
| `/api/workflow/create` | POST | Crea workflow |

## 🔧 Integrazione con Hub Esistente

Aggiungi al tuo `server.js` dell'Hub:

```javascript
const axios = require('axios');
const INTEGRATION_URL = 'http://localhost:3002';

// Proxy verso AI Integration
app.use('/api/ai', async (req, res) => {
  try {
    const response = await axios({
      method: req.method,
      url: `${INTEGRATION_URL}${req.path}`,
      data: req.body
    });
    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});
```

## 📊 WebSocket Events

Connetti a `ws://localhost:3002` per ricevere eventi realtime:

```javascript
const ws = new WebSocket('ws://localhost:3002');

ws.onmessage = (event) => {
  const data = JSON.parse(event.data);
  // data.type: 'status', 'taskComplete', 'taskError', 'agentImproved', 'healthReport'
};
```

## 🧠 Come Funziona il Self-Learning

1. **Memoria Short-Term**: Ultime N interazioni
2. **Pattern Recognition**: Identifica successi/fallimenti
3. **Knowledge Base**: Salva patterns utili
4. **Feedback Loop**: Migliora da errori e feedback
5. **Analisi Periodica**: Ogni 50 task analizza e ottimizza

## 📝 Esempi d'Uso

### Trading Analysis
```javascript
const response = await fetch('http://localhost:3002/api/agents/trading/query', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    prompt: 'Analizza BTC/USD, identifica supporti e resistenze'
  })
});
```

### NFT Prompt Generation
```javascript
const response = await fetch('http://localhost:3002/api/nft/generate-prompt', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    theme: 'Cyberpunk samurai',
    style: 'abstract',
    platform: 'Midjourney'
  })
});
```

## 🛠️ Troubleshooting

**"Nessun provider AI disponibile"**
- Verifica Ollama sia in esecuzione: `ollama serve`
- Oppure configura API keys in `.env`

**WebSocket non si connette**
- Verifica porta 3002 non sia già in uso
- Controlla firewall/antivirus

**Agenti lenti**
- Usa Groq per risposte veloci
- Riduci `maxTokens` nelle query

## 📜 License

MIT - Gene1799 Art Corporation
