/**
 * GENE1799 AI System - Main Entry Point
 */

const config = require('./config/ai-config');
const AIProviderManager = require('./providers/AIProviderManager');
const { SelfLearningAgent, TradingAgent, NFTAgent, WorkflowAgent, SystemAgent } = require('./agents/SpecializedAgents');
const { AgentManager, getInstance } = require('./core/AgentManager');

module.exports = {
  // Config
  config,
  
  // Providers
  AIProviderManager,
  
  // Agents
  SelfLearningAgent,
  TradingAgent,
  NFTAgent,
  WorkflowAgent,
  SystemAgent,
  
  // Manager
  AgentManager,
  getInstance,
  
  // Quick start
  async start(customConfig = {}) {
    const manager = getInstance(customConfig);
    await manager.initialize();
    return manager;
  }
};
