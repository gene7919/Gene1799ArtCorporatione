/**
 * GENE1799 Integration Server
 * Server Express con API REST e WebSocket per dashboard
 */

const express = require('express');
const http = require('http');
const WebSocket = require('ws');
const cors = require('cors');
const path = require('path');
const { AgentManager, getInstance } = require('./AgentManager');

const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, '../dashboard')));

// Agent Manager instance
let agentManager = null;

// === WEBSOCKET ===

const wsClients = new Set();

wss.on('connection', (ws) => {
  console.log('[WS] Client connesso');
  wsClients.add(ws);

  // Invia stato iniziale
  if (agentManager) {
    ws.send(JSON.stringify({
      type: 'status',
      data: agentManager.getStatus()
    }));
  }

  ws.on('message', async (message) => {
    try {
      const data = JSON.parse(message);
      await handleWsMessage(ws, data);
    } catch (error) {
      ws.send(JSON.stringify({ type: 'error', error: error.message }));
    }
  });

  ws.on('close', () => {
    wsClients.delete(ws);
    console.log('[WS] Client disconnesso');
  });
});

async function handleWsMessage(ws, data) {
  switch (data.type) {
    case 'query':
      const result = await agentManager.query(data.agent, data.prompt, data.options);
      ws.send(JSON.stringify({ type: 'queryResult', id: data.id, result }));
      break;
    case 'getStatus':
      ws.send(JSON.stringify({ type: 'status', data: agentManager.getStatus() }));
      break;
    case 'subscribe':
      // Il client è già iscritto agli eventi
      break;
  }
}

function broadcast(type, data) {
  const message = JSON.stringify({ type, data, timestamp: Date.now() });
  wsClients.forEach(client => {
    if (client.readyState === WebSocket.OPEN) {
      client.send(message);
    }
  });
}

// === REST API ===

// Health check
app.get('/integration/health', (req, res) => {
  res.json({
    status: 'online',
    service: 'Gene1799 AI Integration',
    version: '2.0.0',
    systems: {
      hubEnhanced: process.env.HUB_URL || 'http://localhost:3000',
      aiIntegration: 'active',
      agents: agentManager ? 'initialized' : 'pending'
    }
  });
});

// Status completo
app.get('/api/status', (req, res) => {
  if (!agentManager) {
    return res.status(503).json({ error: 'Agent Manager non inizializzato' });
  }
  res.json(agentManager.getStatus());
});

// Lista agenti
app.get('/api/agents', (req, res) => {
  if (!agentManager) {
    return res.status(503).json({ error: 'Agent Manager non inizializzato' });
  }
  res.json(agentManager.listAgents());
});

// Health agenti
app.get('/api/agents/health', (req, res) => {
  if (!agentManager) {
    return res.status(503).json({ error: 'Agent Manager non inizializzato' });
  }
  
  const agents = agentManager.listAgents();
  const health = {
    status: 'online',
    agents: agents.map(a => ({
      name: a.name,
      status: a.status,
      performance: a.performance
    })),
    timestamp: Date.now()
  };
  
  res.json(health);
});

// Query singolo agente
app.post('/api/agents/:agent/query', async (req, res) => {
  try {
    if (!agentManager) {
      return res.status(503).json({ error: 'Agent Manager non inizializzato' });
    }

    const { agent } = req.params;
    const { prompt, options } = req.body;

    const result = await agentManager.query(agent, prompt, options);
    res.json({ success: true, result });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Train agente
app.post('/api/agents/:agent/train', async (req, res) => {
  try {
    if (!agentManager) {
      return res.status(503).json({ error: 'Agent Manager non inizializzato' });
    }

    const { agent } = req.params;
    const { trainingData } = req.body;

    const result = await agentManager.train(agent, trainingData || []);
    res.json({ success: true, result });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Train tutti gli agenti
app.post('/api/agents/train', async (req, res) => {
  try {
    if (!agentManager) {
      return res.status(503).json({ error: 'Agent Manager non inizializzato' });
    }

    const results = {};
    const agents = agentManager.listAgents();
    
    for (const agent of agents) {
      results[agent.name] = await agentManager.train(agent.name, []);
    }

    res.json({ success: true, results });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Submit task
app.post('/api/tasks', async (req, res) => {
  try {
    if (!agentManager) {
      return res.status(503).json({ error: 'Agent Manager non inizializzato' });
    }

    const taskId = await agentManager.submitTask(req.body);
    res.json({ success: true, taskId });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Provider AI status
app.get('/api/providers', (req, res) => {
  if (!agentManager) {
    return res.status(503).json({ error: 'Agent Manager non inizializzato' });
  }
  res.json({
    providers: agentManager.aiProvider.getAvailableProviders(),
    stats: agentManager.aiProvider.getStats()
  });
});

// Health check provider AI
app.get('/api/providers/health', async (req, res) => {
  try {
    if (!agentManager) {
      return res.status(503).json({ error: 'Agent Manager non inizializzato' });
    }
    const health = await agentManager.aiProvider.checkHealth();
    res.json(health);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// === ENDPOINTS SPECIFICI ===

// Trading analysis
app.post('/api/trading/analyze', async (req, res) => {
  try {
    const { symbol, timeframe, marketData } = req.body;
    const result = await agentManager.query('trading', 
      `Analizza ${symbol} su timeframe ${timeframe || '1h'}`,
      { marketData }
    );
    res.json({ success: true, analysis: result });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// NFT generation
app.post('/api/nft/generate-prompt', async (req, res) => {
  try {
    const { theme, style, mood, platform } = req.body;
    const result = await agentManager.query('nft',
      'Genera art prompt',
      { subtype: 'generate-prompt', theme, style, mood, platform }
    );
    res.json({ success: true, prompt: result });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Workflow creation
app.post('/api/workflow/create', async (req, res) => {
  try {
    const { goal, requirements, inputs, outputs } = req.body;
    const result = await agentManager.query('workflow',
      'Crea workflow',
      { subtype: 'create-workflow', goal, requirements, inputs, outputs }
    );
    res.json({ success: true, workflow: result });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// System diagnostics
app.get('/api/system/diagnostics', async (req, res) => {
  try {
    const systemAgent = agentManager.getAgent('system');
    const health = await systemAgent.checkSystemHealth();
    res.json(health);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// === INIZIALIZZAZIONE ===

async function initializeServer() {
  console.log('[Server] Inizializzazione Agent Manager...');
  
  agentManager = getInstance();
  await agentManager.initialize();

  // Setup event forwarding to WebSocket
  agentManager.on('taskSubmitted', (data) => broadcast('taskSubmitted', data));
  agentManager.on('agentTaskComplete', (data) => broadcast('taskComplete', data));
  agentManager.on('agentTaskError', (data) => broadcast('taskError', data));
  agentManager.on('agentImproved', (data) => broadcast('agentImproved', data));
  agentManager.on('healthReport', (data) => broadcast('healthReport', data));

  console.log('[Server] Agent Manager pronto');
}

// === AVVIO ===

const PORT = process.env.INTEGRATION_PORT || 3002;

server.listen(PORT, async () => {
  console.log(`\n╔════════════════════════════════════════════════════════════════╗`);
  console.log(`║   GENE1799 AI Integration Server v2.0                         ║`);
  console.log(`║   Port: ${PORT} | Multi-AI | Self-Learning Agents              ║`);
  console.log(`╚════════════════════════════════════════════════════════════════╝\n`);

  await initializeServer();

  console.log(`\n[Server] Endpoints disponibili:`);
  console.log(`  GET  /integration/health     - Health check`);
  console.log(`  GET  /api/status             - Status completo`);
  console.log(`  GET  /api/agents             - Lista agenti`);
  console.log(`  GET  /api/agents/health      - Health agenti`);
  console.log(`  POST /api/agents/:name/query - Query agente`);
  console.log(`  POST /api/agents/train       - Training agenti`);
  console.log(`  POST /api/tasks              - Submit task`);
  console.log(`  GET  /api/providers          - AI providers status`);
  console.log(`  POST /api/trading/analyze    - Analisi trading`);
  console.log(`  POST /api/nft/generate-prompt- Genera prompt NFT`);
  console.log(`  POST /api/workflow/create    - Crea workflow`);
  console.log(`  WS   ws://localhost:${PORT}   - WebSocket realtime\n`);
});

// Graceful shutdown
process.on('SIGINT', async () => {
  console.log('\n[Server] Shutdown in corso...');
  if (agentManager) {
    await agentManager.shutdown();
  }
  process.exit(0);
});

module.exports = { app, server };
