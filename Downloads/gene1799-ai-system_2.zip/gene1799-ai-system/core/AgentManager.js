/**
 * GENE1799 Agent Manager
 * Orchestratore centrale per tutti gli agenti AI
 */

const EventEmitter = require('events');
const AIProviderManager = require('../providers/AIProviderManager');
const { TradingAgent, NFTAgent, WorkflowAgent, SystemAgent } = require('./SpecializedAgents');
const config = require('../config/ai-config');

class AgentManager extends EventEmitter {
  constructor(customConfig = {}) {
    super();
    this.config = { ...config, ...customConfig };
    this.agents = new Map();
    this.taskQueue = [];
    this.isProcessing = false;
    this.stats = {
      totalTasks: 0,
      completedTasks: 0,
      failedTasks: 0,
      startTime: Date.now()
    };

    // Inizializza AI Provider
    this.aiProvider = new AIProviderManager(this.config);
    
    console.log('[AgentManager] Inizializzato');
  }

  // === INIZIALIZZAZIONE ===

  async initialize() {
    console.log('[AgentManager] Avvio inizializzazione...');

    // Check salute provider AI
    const health = await this.aiProvider.checkHealth();
    console.log('[AgentManager] Health check AI:', health);

    // Inizializza agenti specializzati
    await this.initializeAgents();

    // Avvia loop di processing
    this.startProcessingLoop();

    // Avvia health monitoring
    this.startHealthMonitoring();

    this.emit('initialized', { agents: [...this.agents.keys()], health });
    console.log('[AgentManager] Inizializzazione completata');
    
    return this;
  }

  async initializeAgents() {
    // Trading Agent
    const tradingAgent = new TradingAgent(this.aiProvider);
    await tradingAgent.initialize();
    this.agents.set('trading', tradingAgent);
    this.setupAgentListeners(tradingAgent);

    // NFT Agent
    const nftAgent = new NFTAgent(this.aiProvider);
    await nftAgent.initialize();
    this.agents.set('nft', nftAgent);
    this.setupAgentListeners(nftAgent);

    // Workflow Agent
    const workflowAgent = new WorkflowAgent(this.aiProvider);
    await workflowAgent.initialize();
    this.agents.set('workflow', workflowAgent);
    this.setupAgentListeners(workflowAgent);

    // System Agent (self-healing)
    const systemAgent = new SystemAgent(this.aiProvider);
    await systemAgent.initialize();
    this.agents.set('system', systemAgent);
    this.setupAgentListeners(systemAgent);

    // Registra componenti nel system agent
    systemAgent.registerComponent('ai-provider', { type: 'core', checkFn: () => this.aiProvider.checkHealth() });
    systemAgent.registerComponent('task-queue', { type: 'core', checkFn: () => ({ length: this.taskQueue.length }) });

    console.log(`[AgentManager] ${this.agents.size} agenti inizializzati`);
  }

  setupAgentListeners(agent) {
    agent.on('taskComplete', (data) => {
      this.stats.completedTasks++;
      this.emit('agentTaskComplete', data);
    });

    agent.on('taskError', (data) => {
      this.stats.failedTasks++;
      this.emit('agentTaskError', data);
    });

    agent.on('improved', (data) => {
      this.emit('agentImproved', data);
    });
  }

  // === GESTIONE TASK ===

  async submitTask(task) {
    const taskWithMeta = {
      ...task,
      id: task.id || `task_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      submittedAt: Date.now(),
      status: 'queued'
    };

    this.taskQueue.push(taskWithMeta);
    this.stats.totalTasks++;

    this.emit('taskSubmitted', { taskId: taskWithMeta.id, queueLength: this.taskQueue.length });
    
    return taskWithMeta.id;
  }

  async processTask(task) {
    // Determina quale agente gestisce il task
    const agent = this.routeTask(task);
    
    if (!agent) {
      throw new Error(`Nessun agente disponibile per task type: ${task.type}`);
    }

    task.status = 'processing';
    task.agent = agent.name;
    task.startedAt = Date.now();

    try {
      const result = await agent.execute(task);
      task.status = 'completed';
      task.completedAt = Date.now();
      task.result = result;
      return result;
    } catch (error) {
      task.status = 'failed';
      task.error = error.message;
      throw error;
    }
  }

  routeTask(task) {
    const typeMap = {
      'trading': 'trading',
      'market-analysis': 'trading',
      'price-prediction': 'trading',
      'nft': 'nft',
      'nft-generation': 'nft',
      'art-prompt': 'nft',
      'metadata': 'nft',
      'workflow': 'workflow',
      'automation': 'workflow',
      'orchestrate': 'workflow',
      'system': 'system',
      'health-check': 'system',
      'diagnose': 'system'
    };

    const agentKey = typeMap[task.type] || 'workflow'; // Default a workflow
    return this.agents.get(agentKey);
  }

  // === PROCESSING LOOP ===

  startProcessingLoop() {
    setInterval(async () => {
      if (this.isProcessing || this.taskQueue.length === 0) return;

      this.isProcessing = true;
      
      try {
        // Processa fino a 3 task in parallelo
        const tasksToProcess = this.taskQueue.splice(0, 3);
        
        await Promise.allSettled(
          tasksToProcess.map(task => this.processTask(task))
        );
      } catch (error) {
        console.error('[AgentManager] Processing error:', error);
      }

      this.isProcessing = false;
    }, 1000); // Check ogni secondo
  }

  // === HEALTH MONITORING ===

  startHealthMonitoring() {
    // Health check ogni 30 secondi
    setInterval(async () => {
      try {
        const systemAgent = this.agents.get('system');
        if (systemAgent) {
          const health = await systemAgent.checkSystemHealth();
          this.emit('healthReport', health);

          // Auto-repair se necessario
          if (health.issues.length > 0) {
            await this.attemptAutoRepair(health.issues);
          }
        }
      } catch (error) {
        console.error('[AgentManager] Health check error:', error);
      }
    }, 30000);
  }

  async attemptAutoRepair(issues) {
    console.log(`[AgentManager] Tentativo auto-repair per ${issues.length} issues`);

    for (const issue of issues) {
      if (issue.severity === 'critical') {
        // Per issues critici, tenta repair
        try {
          await this.repairComponent(issue.component, issue);
          this.emit('repairAttempted', { component: issue.component, success: true });
        } catch (error) {
          this.emit('repairAttempted', { component: issue.component, success: false, error: error.message });
        }
      }
    }
  }

  async repairComponent(componentName, issue) {
    console.log(`[AgentManager] Repairing ${componentName}:`, issue);
    
    // Logica di repair base
    switch (componentName) {
      case 'ai-provider':
        // Ricontrolla e reinizializza se necessario
        await this.aiProvider.checkHealth();
        break;
      case 'task-queue':
        // Pulisci task vecchi
        this.taskQueue = this.taskQueue.filter(t => 
          Date.now() - t.submittedAt < 3600000 // < 1 ora
        );
        break;
      default:
        // Tenta restart agente
        const agent = this.agents.get(componentName);
        if (agent) {
          await agent.shutdown();
          await agent.initialize();
        }
    }
  }

  // === API PUBBLICA ===

  async query(agentType, prompt, options = {}) {
    const agent = this.agents.get(agentType);
    if (!agent) {
      throw new Error(`Agent '${agentType}' non trovato`);
    }

    return await agent.execute({
      type: agentType,
      prompt,
      ...options
    });
  }

  async train(agentType, trainingData) {
    const agent = this.agents.get(agentType);
    if (!agent) {
      throw new Error(`Agent '${agentType}' non trovato`);
    }

    // Simula training con feedback
    for (const sample of trainingData) {
      agent.receiveFeedback({
        task: sample.task,
        rating: sample.rating,
        comment: sample.feedback
      });
    }

    // Forza analisi e miglioramento
    await agent.analyzeAndImprove();

    return { trained: true, samples: trainingData.length };
  }

  getStatus() {
    const agentStats = {};
    for (const [name, agent] of this.agents) {
      agentStats[name] = agent.getStats();
    }

    return {
      status: 'online',
      uptime: Date.now() - this.stats.startTime,
      stats: this.stats,
      queueLength: this.taskQueue.length,
      agents: agentStats,
      providers: this.aiProvider.getAvailableProviders(),
      providerStats: this.aiProvider.getStats()
    };
  }

  getAgent(name) {
    return this.agents.get(name);
  }

  listAgents() {
    return [...this.agents.keys()].map(name => ({
      name,
      status: this.agents.get(name).state.status,
      performance: this.agents.get(name).state.performance
    }));
  }

  // === SHUTDOWN ===

  async shutdown() {
    console.log('[AgentManager] Shutting down...');

    for (const [name, agent] of this.agents) {
      console.log(`[AgentManager] Stopping ${name}...`);
      await agent.shutdown();
    }

    this.emit('shutdown');
    console.log('[AgentManager] Shutdown complete');
  }
}

// Singleton instance
let instance = null;

module.exports = {
  AgentManager,
  getInstance: (config) => {
    if (!instance) {
      instance = new AgentManager(config);
    }
    return instance;
  }
};
