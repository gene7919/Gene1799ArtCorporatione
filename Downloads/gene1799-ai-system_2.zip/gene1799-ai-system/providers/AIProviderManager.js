/**
 * GENE1799 AI Provider Manager
 * Gestisce connessioni multiple AI con fallback automatico
 */

const axios = require('axios');
const EventEmitter = require('events');

class AIProviderManager extends EventEmitter {
  constructor(config) {
    super();
    this.config = config;
    this.providers = new Map();
    this.stats = new Map();
    this.healthStatus = new Map();
    
    this.initProviders();
  }

  initProviders() {
    const { providers } = this.config;

    // Ollama (locale)
    if (providers.ollama?.enabled) {
      this.providers.set('ollama', {
        name: 'Ollama',
        type: 'local',
        call: (model, prompt, options) => this.callOllama(model, prompt, options),
        models: providers.ollama.models,
        config: providers.ollama
      });
    }

    // OpenAI
    if (providers.openai?.enabled) {
      this.providers.set('openai', {
        name: 'OpenAI',
        type: 'cloud',
        call: (model, prompt, options) => this.callOpenAI(model, prompt, options),
        models: providers.openai.models,
        config: providers.openai
      });
    }

    // Anthropic
    if (providers.anthropic?.enabled) {
      this.providers.set('anthropic', {
        name: 'Anthropic',
        type: 'cloud',
        call: (model, prompt, options) => this.callAnthropic(model, prompt, options),
        models: providers.anthropic.models,
        config: providers.anthropic
      });
    }

    // Groq (ultra-veloce)
    if (providers.groq?.enabled) {
      this.providers.set('groq', {
        name: 'Groq',
        type: 'cloud',
        call: (model, prompt, options) => this.callGroq(model, prompt, options),
        models: providers.groq.models,
        config: providers.groq
      });
    }

    console.log(`[AIProvider] Inizializzati ${this.providers.size} provider:`, 
      [...this.providers.keys()].join(', '));
  }

  // === CHIAMATE AI ===

  async callOllama(model, prompt, options = {}) {
    const config = this.config.providers.ollama;
    const startTime = Date.now();

    try {
      const response = await axios.post(`${config.baseUrl}/api/generate`, {
        model: config.models[model] || model,
        prompt,
        stream: false,
        options: {
          temperature: options.temperature || 0.7,
          num_predict: options.maxTokens || 2048
        }
      }, { timeout: config.timeout });

      this.recordStats('ollama', Date.now() - startTime, true);
      return {
        success: true,
        provider: 'ollama',
        model: config.models[model] || model,
        content: response.data.response,
        usage: {
          promptTokens: response.data.prompt_eval_count,
          completionTokens: response.data.eval_count,
          totalTokens: (response.data.prompt_eval_count || 0) + (response.data.eval_count || 0)
        },
        latency: Date.now() - startTime
      };
    } catch (error) {
      this.recordStats('ollama', Date.now() - startTime, false);
      throw new Error(`Ollama error: ${error.message}`);
    }
  }

  async callOpenAI(model, prompt, options = {}) {
    const config = this.config.providers.openai;
    const startTime = Date.now();

    try {
      const response = await axios.post('https://api.openai.com/v1/chat/completions', {
        model: config.models[model] || model,
        messages: [
          { role: 'system', content: options.systemPrompt || 'Sei un assistente AI di Gene1799.' },
          { role: 'user', content: prompt }
        ],
        temperature: options.temperature || 0.7,
        max_tokens: options.maxTokens || 2048
      }, {
        headers: {
          'Authorization': `Bearer ${config.apiKey}`,
          'Content-Type': 'application/json'
        },
        timeout: config.timeout
      });

      this.recordStats('openai', Date.now() - startTime, true);
      return {
        success: true,
        provider: 'openai',
        model: config.models[model] || model,
        content: response.data.choices[0].message.content,
        usage: response.data.usage,
        latency: Date.now() - startTime
      };
    } catch (error) {
      this.recordStats('openai', Date.now() - startTime, false);
      throw new Error(`OpenAI error: ${error.message}`);
    }
  }

  async callAnthropic(model, prompt, options = {}) {
    const config = this.config.providers.anthropic;
    const startTime = Date.now();

    try {
      const response = await axios.post('https://api.anthropic.com/v1/messages', {
        model: config.models[model] || model,
        max_tokens: options.maxTokens || 2048,
        messages: [{ role: 'user', content: prompt }]
      }, {
        headers: {
          'x-api-key': config.apiKey,
          'anthropic-version': '2023-06-01',
          'Content-Type': 'application/json'
        },
        timeout: config.timeout
      });

      this.recordStats('anthropic', Date.now() - startTime, true);
      return {
        success: true,
        provider: 'anthropic',
        model: config.models[model] || model,
        content: response.data.content[0].text,
        usage: response.data.usage,
        latency: Date.now() - startTime
      };
    } catch (error) {
      this.recordStats('anthropic', Date.now() - startTime, false);
      throw new Error(`Anthropic error: ${error.message}`);
    }
  }

  async callGroq(model, prompt, options = {}) {
    const config = this.config.providers.groq;
    const startTime = Date.now();

    try {
      const response = await axios.post('https://api.groq.com/openai/v1/chat/completions', {
        model: config.models[model] || model,
        messages: [{ role: 'user', content: prompt }],
        temperature: options.temperature || 0.7,
        max_tokens: options.maxTokens || 2048
      }, {
        headers: {
          'Authorization': `Bearer ${config.apiKey}`,
          'Content-Type': 'application/json'
        },
        timeout: config.timeout
      });

      this.recordStats('groq', Date.now() - startTime, true);
      return {
        success: true,
        provider: 'groq',
        model: config.models[model] || model,
        content: response.data.choices[0].message.content,
        usage: response.data.usage,
        latency: Date.now() - startTime
      };
    } catch (error) {
      this.recordStats('groq', Date.now() - startTime, false);
      throw new Error(`Groq error: ${error.message}`);
    }
  }

  // === ROUTING INTELLIGENTE ===

  async query(taskType, prompt, options = {}) {
    const routing = this.config.routing.taskRouting[taskType] || 
                    this.config.routing.taskRouting['quick-response'];
    
    let lastError = null;

    for (const providerSpec of routing) {
      const [providerName, modelType] = providerSpec.split(':');
      const provider = this.providers.get(providerName);

      if (!provider) continue;

      // Check health prima di chiamare
      if (this.healthStatus.get(providerName) === 'down') {
        console.log(`[AIProvider] Skipping ${providerName} (marked as down)`);
        continue;
      }

      try {
        console.log(`[AIProvider] Trying ${providerName}:${modelType} for ${taskType}`);
        const result = await provider.call(modelType, prompt, options);
        this.emit('response', { taskType, provider: providerName, success: true });
        return result;
      } catch (error) {
        console.log(`[AIProvider] ${providerName} failed: ${error.message}`);
        lastError = error;
        continue;
      }
    }

    // Fallback chain
    for (const providerName of this.config.routing.fallbackChain) {
      const provider = this.providers.get(providerName);
      if (!provider) continue;

      try {
        console.log(`[AIProvider] Fallback to ${providerName}`);
        const result = await provider.call('fast', prompt, options);
        return result;
      } catch (error) {
        lastError = error;
        continue;
      }
    }

    throw lastError || new Error('Nessun provider AI disponibile');
  }

  // === HEALTH CHECK ===

  async checkHealth() {
    const results = {};

    for (const [name, provider] of this.providers) {
      try {
        if (name === 'ollama') {
          await axios.get(`${provider.config.baseUrl}/api/tags`, { timeout: 5000 });
        } else {
          // Per cloud providers, test leggero
          await provider.call('fast', 'test', { maxTokens: 5 });
        }
        this.healthStatus.set(name, 'up');
        results[name] = { status: 'online', type: provider.type };
      } catch (error) {
        this.healthStatus.set(name, 'down');
        results[name] = { status: 'offline', error: error.message };
      }
    }

    this.emit('healthCheck', results);
    return results;
  }

  // === STATISTICHE ===

  recordStats(provider, latency, success) {
    if (!this.stats.has(provider)) {
      this.stats.set(provider, {
        calls: 0,
        successes: 0,
        failures: 0,
        totalLatency: 0,
        avgLatency: 0
      });
    }

    const stats = this.stats.get(provider);
    stats.calls++;
    if (success) stats.successes++;
    else stats.failures++;
    stats.totalLatency += latency;
    stats.avgLatency = Math.round(stats.totalLatency / stats.calls);
  }

  getStats() {
    const result = {};
    for (const [name, stats] of this.stats) {
      result[name] = {
        ...stats,
        successRate: stats.calls > 0 ? 
          Math.round((stats.successes / stats.calls) * 100) : 0
      };
    }
    return result;
  }

  getAvailableProviders() {
    return [...this.providers.keys()].map(name => ({
      name,
      type: this.providers.get(name).type,
      models: Object.keys(this.providers.get(name).models),
      status: this.healthStatus.get(name) || 'unknown'
    }));
  }
}

module.exports = AIProviderManager;
