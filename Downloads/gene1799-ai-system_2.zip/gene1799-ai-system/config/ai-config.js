/**
 * GENE1799 AI Configuration
 * Configurazione Multi-AI per agenti auto-imparanti
 */

module.exports = {
  // Provider AI disponibili
  providers: {
    ollama: {
      enabled: true,
      baseUrl: process.env.OLLAMA_URL || 'http://localhost:11434',
      models: {
        fast: 'llama2',           // Risposte veloci
        smart: 'mistral',         // Analisi complesse
        code: 'codellama',        // Generazione codice
        vision: 'llava'           // Analisi immagini
      },
      timeout: 120000
    },
    openai: {
      enabled: !!process.env.OPENAI_API_KEY,
      apiKey: process.env.OPENAI_API_KEY,
      models: {
        fast: 'gpt-3.5-turbo',
        smart: 'gpt-4-turbo-preview',
        vision: 'gpt-4-vision-preview'
      },
      timeout: 60000
    },
    anthropic: {
      enabled: !!process.env.ANTHROPIC_API_KEY,
      apiKey: process.env.ANTHROPIC_API_KEY,
      models: {
        smart: 'claude-3-opus-20240229',
        fast: 'claude-3-haiku-20240307'
      },
      timeout: 60000
    },
    groq: {
      enabled: !!process.env.GROQ_API_KEY,
      apiKey: process.env.GROQ_API_KEY,
      models: {
        fast: 'mixtral-8x7b-32768',
        smart: 'llama2-70b-4096'
      },
      timeout: 30000
    }
  },

  // Strategia di routing AI
  routing: {
    // Quale provider usare per ogni tipo di task
    taskRouting: {
      'trading': ['ollama:smart', 'openai:smart', 'anthropic:smart'],
      'nft-generation': ['ollama:vision', 'openai:vision'],
      'code-generation': ['ollama:code', 'openai:smart'],
      'quick-response': ['groq:fast', 'ollama:fast', 'openai:fast'],
      'complex-analysis': ['anthropic:smart', 'openai:smart', 'ollama:smart'],
      'workflow': ['ollama:fast', 'groq:fast']
    },
    // Fallback automatico se provider non disponibile
    fallbackChain: ['ollama', 'groq', 'openai', 'anthropic']
  },

  // Sistema di apprendimento
  learning: {
    enabled: true,
    storePath: './data/learning',
    // Salva feedback per miglioramento
    saveFeedback: true,
    // Analizza performance ogni N richieste
    analyzeEvery: 100,
    // Metriche da tracciare
    metrics: ['responseTime', 'accuracy', 'userSatisfaction', 'cost']
  },

  // Hub Integration
  hub: {
    url: process.env.HUB_URL || 'http://localhost:3000',
    integrationUrl: process.env.INTEGRATION_URL || 'http://localhost:3002',
    websocket: process.env.WS_URL || 'ws://localhost:3000'
  }
};
