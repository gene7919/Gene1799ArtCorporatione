/**
 * GENE1799 Specialized Agents
 * Agenti specializzati per diversi domini
 */

const SelfLearningAgent = require('./SelfLearningAgent');

// ================================================
// TRADING AGENT - Analisi mercati e strategie
// ================================================
class TradingAgent extends SelfLearningAgent {
  constructor(aiProvider, options = {}) {
    super('TradingAgent', aiProvider, {
      ...options,
      memoryLimit: 200,
      improvementCycle: 30
    });

    this.tradingKnowledge = {
      indicators: ['RSI', 'MACD', 'SMA', 'EMA', 'Bollinger'],
      patterns: ['head-shoulders', 'double-top', 'triangle', 'wedge'],
      strategies: new Map()
    };
  }

  getSystemPrompt() {
    return `Sei TradingAgent di Gene1799 Art Corporation.
Sei un esperto analista di mercati finanziari e crypto.
Competenze:
- Analisi tecnica (${this.tradingKnowledge.indicators.join(', ')})
- Pattern recognition (${this.tradingKnowledge.patterns.join(', ')})
- Risk management e position sizing
- Correlazioni inter-market

Rispondi SEMPRE con dati concreti e actionable insights.
Indica sempre il livello di confidenza delle tue analisi.`;
  }

  async processTask(task, context) {
    // Arricchisci il task con contesto di mercato
    const enrichedTask = {
      ...task,
      prompt: this.enrichTradingPrompt(task.prompt, task)
    };

    return await super.processTask(enrichedTask, context);
  }

  enrichTradingPrompt(prompt, task) {
    let enriched = prompt;

    // Aggiungi contesto di mercato se disponibile
    if (task.marketData) {
      enriched += `\n\nDati di mercato attuali:\n${JSON.stringify(task.marketData, null, 2)}`;
    }

    // Aggiungi strategie apprese
    if (this.tradingKnowledge.strategies.size > 0) {
      const relevantStrategies = [...this.tradingKnowledge.strategies.entries()]
        .filter(([_, s]) => s.successRate > 60)
        .slice(0, 3);
      
      if (relevantStrategies.length > 0) {
        enriched += `\n\nStrategie con alto success rate:\n${
          relevantStrategies.map(([name, s]) => 
            `- ${name}: ${s.successRate}% (${s.trades} trades)`
          ).join('\n')
        }`;
      }
    }

    return enriched;
  }

  async postProcess(task, response) {
    const result = await super.postProcess(task, response);

    // Estrai segnali dal response
    result.signals = this.extractSignals(response.content);
    result.confidence = this.calculateConfidence(response.content);
    result.riskLevel = this.assessRisk(response.content);

    return result;
  }

  extractSignals(content) {
    const signals = [];
    const buyMatch = content.match(/\b(buy|long|accumulate|bullish)\b/gi);
    const sellMatch = content.match(/\b(sell|short|reduce|bearish)\b/gi);
    
    if (buyMatch) signals.push({ type: 'BUY', strength: buyMatch.length });
    if (sellMatch) signals.push({ type: 'SELL', strength: sellMatch.length });

    return signals;
  }

  calculateConfidence(content) {
    // Cerca indicatori di confidenza nel testo
    const highConf = (content.match(/\b(strongly|definitely|clearly|high probability)\b/gi) || []).length;
    const lowConf = (content.match(/\b(possibly|maybe|uncertain|risky)\b/gi) || []).length;
    
    return Math.min(100, Math.max(0, 50 + (highConf * 10) - (lowConf * 15)));
  }

  assessRisk(content) {
    const riskWords = (content.match(/\b(risk|volatile|danger|caution|warning)\b/gi) || []).length;
    if (riskWords >= 3) return 'HIGH';
    if (riskWords >= 1) return 'MEDIUM';
    return 'LOW';
  }

  // Metodo per registrare risultati di trade
  recordTradeResult(strategyName, success, profit) {
    if (!this.tradingKnowledge.strategies.has(strategyName)) {
      this.tradingKnowledge.strategies.set(strategyName, {
        trades: 0,
        wins: 0,
        losses: 0,
        totalProfit: 0,
        successRate: 0
      });
    }

    const strategy = this.tradingKnowledge.strategies.get(strategyName);
    strategy.trades++;
    if (success) strategy.wins++;
    else strategy.losses++;
    strategy.totalProfit += profit;
    strategy.successRate = Math.round((strategy.wins / strategy.trades) * 100);
  }
}

// ================================================
// NFT AGENT - Generazione arte e NFT
// ================================================
class NFTAgent extends SelfLearningAgent {
  constructor(aiProvider, options = {}) {
    super('NFTAgent', aiProvider, {
      ...options,
      memoryLimit: 150
    });

    this.artKnowledge = {
      styles: ['abstract', 'cyberpunk', 'surrealist', 'minimalist', 'pop-art', 'generative'],
      mediums: ['digital-painting', '3d-render', 'pixel-art', 'ai-generated', 'mixed-media'],
      trendingThemes: [],
      collections: new Map()
    };
  }

  getSystemPrompt() {
    return `Sei NFTAgent di Gene1799 Art Corporation.
Sei un esperto creatore e curatore di NFT e arte digitale.
Competenze:
- Generazione prompt per AI art (Midjourney, DALL-E, Stable Diffusion)
- Analisi trend NFT e mercato arte digitale
- Curation e valutazione artistica
- Storytelling e narrative per collezioni
- Ottimizzazione metadata e traits

Stili padroneggiati: ${this.artKnowledge.styles.join(', ')}
Medium: ${this.artKnowledge.mediums.join(', ')}

Crea sempre contenuti originali e innovativi.`;
  }

  async processTask(task, context) {
    // Specializza per tipo di task NFT
    switch (task.subtype) {
      case 'generate-prompt':
        return this.generateArtPrompt(task, context);
      case 'analyze-collection':
        return this.analyzeCollection(task, context);
      case 'create-metadata':
        return this.createMetadata(task, context);
      default:
        return super.processTask(task, context);
    }
  }

  async generateArtPrompt(task, context) {
    const enhancedTask = {
      ...task,
      prompt: `Genera un prompt dettagliato per AI art.
Tema: ${task.theme || 'astratto futuristico'}
Stile: ${task.style || 'cyberpunk'}
Mood: ${task.mood || 'misterioso'}
Dettagli extra: ${task.details || 'alta qualità, 8k, dettagliato'}

Il prompt deve essere ottimizzato per ${task.platform || 'Midjourney'}.
Includi: composizione, lighting, color palette, stile artistico specifico.`
    };

    const response = await super.processTask(enhancedTask, context);
    
    // Post-process: estrai il prompt generato
    response.artPrompt = this.extractArtPrompt(response.content);
    response.suggestedPlatform = task.platform || 'Midjourney';

    return response;
  }

  extractArtPrompt(content) {
    // Cerca il prompt tra virgolette o dopo "Prompt:"
    const quotedMatch = content.match(/"([^"]{50,})"/);
    if (quotedMatch) return quotedMatch[1];

    const labeledMatch = content.match(/(?:Prompt|prompt):\s*(.+?)(?:\n\n|\n-|$)/s);
    if (labeledMatch) return labeledMatch[1].trim();

    // Fallback: prima frase lunga
    const sentences = content.split(/[.!?]/);
    return sentences.find(s => s.length > 50)?.trim() || content.substring(0, 200);
  }

  async analyzeCollection(task, context) {
    const analysisTask = {
      ...task,
      prompt: `Analizza questa collezione NFT:
Nome: ${task.collectionName}
Dati: ${JSON.stringify(task.collectionData, null, 2)}

Fornisci:
1. Analisi artistica (stile, coerenza, originalità)
2. Analisi di mercato (floor price trend, volume, holder distribution)
3. Punti di forza e debolezze
4. Suggerimenti per miglioramento
5. Valutazione complessiva (1-10)`
    };

    return super.processTask(analysisTask, context);
  }

  async createMetadata(task, context) {
    const metadataTask = {
      ...task,
      prompt: `Crea metadata NFT per:
Nome collezione: ${task.collectionName}
Nome NFT: ${task.nftName}
Descrizione base: ${task.description}
Traits richiesti: ${task.traits?.join(', ') || 'auto-genera'}

Output in formato JSON con:
- name
- description (storytelling coinvolgente)
- attributes (array di trait_type/value)
- external_url
- animation_url (se applicabile)`
    };

    const response = await super.processTask(metadataTask, context);
    
    // Estrai JSON dal response
    try {
      const jsonMatch = response.content.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        response.metadata = JSON.parse(jsonMatch[0]);
      }
    } catch (e) {
      response.parseError = 'Could not extract JSON metadata';
    }

    return response;
  }

  // Traccia trend
  recordTrend(theme, popularity) {
    const existingIndex = this.artKnowledge.trendingThemes.findIndex(t => t.theme === theme);
    if (existingIndex >= 0) {
      this.artKnowledge.trendingThemes[existingIndex].popularity = popularity;
    } else {
      this.artKnowledge.trendingThemes.push({ theme, popularity, addedAt: Date.now() });
    }
    // Mantieni top 20
    this.artKnowledge.trendingThemes.sort((a, b) => b.popularity - a.popularity);
    this.artKnowledge.trendingThemes = this.artKnowledge.trendingThemes.slice(0, 20);
  }
}

// ================================================
// WORKFLOW AGENT - Automazione e orchestrazione
// ================================================
class WorkflowAgent extends SelfLearningAgent {
  constructor(aiProvider, options = {}) {
    super('WorkflowAgent', aiProvider, {
      ...options,
      memoryLimit: 100,
      improvementCycle: 20
    });

    this.workflows = new Map();
    this.automations = [];
  }

  getSystemPrompt() {
    return `Sei WorkflowAgent di Gene1799 Art Corporation.
Sei un esperto di automazione, orchestrazione e ottimizzazione processi.
Competenze:
- Design e ottimizzazione workflow
- Automazione task ripetitivi
- Orchestrazione multi-agente
- Error handling e recovery
- Performance monitoring

Workflow attivi: ${this.workflows.size}
Automazioni configurate: ${this.automations.length}

Crea sempre workflow efficienti, robusti e scalabili.`;
  }

  async processTask(task, context) {
    switch (task.subtype) {
      case 'create-workflow':
        return this.createWorkflow(task, context);
      case 'optimize-workflow':
        return this.optimizeWorkflow(task, context);
      case 'orchestrate':
        return this.orchestrateTasks(task, context);
      default:
        return super.processTask(task, context);
    }
  }

  async createWorkflow(task, context) {
    const workflowTask = {
      ...task,
      prompt: `Crea un workflow per: ${task.goal}

Requisiti:
${task.requirements?.map(r => `- ${r}`).join('\n') || '- Efficienza\n- Robustezza'}

Input disponibili: ${task.inputs?.join(', ') || 'vari'}
Output attesi: ${task.outputs?.join(', ') || 'risultato ottimizzato'}

Genera un workflow in formato JSON con:
- id
- name
- description
- steps: [{ id, name, action, input, output, errorHandler }]
- triggers: [{ type, condition }]
- notifications: [{ event, channel }]`
    };

    const response = await super.processTask(workflowTask, context);
    
    // Estrai e salva workflow
    try {
      const jsonMatch = response.content.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        const workflow = JSON.parse(jsonMatch[0]);
        this.workflows.set(workflow.id || `wf_${Date.now()}`, workflow);
        response.workflow = workflow;
      }
    } catch (e) {
      response.parseError = 'Could not extract workflow JSON';
    }

    return response;
  }

  async optimizeWorkflow(task, context) {
    const workflow = this.workflows.get(task.workflowId);
    if (!workflow) {
      throw new Error(`Workflow ${task.workflowId} non trovato`);
    }

    const optimizeTask = {
      ...task,
      prompt: `Ottimizza questo workflow:
${JSON.stringify(workflow, null, 2)}

Metriche attuali:
- Tempo medio esecuzione: ${task.metrics?.avgTime || 'N/A'}
- Tasso errori: ${task.metrics?.errorRate || 'N/A'}
- Bottleneck identificati: ${task.metrics?.bottlenecks?.join(', ') || 'nessuno'}

Suggerisci ottimizzazioni per:
1. Ridurre tempo di esecuzione
2. Migliorare resilienza
3. Parallelizzare dove possibile
4. Ridurre costi risorse`
    };

    return super.processTask(optimizeTask, context);
  }

  async orchestrateTasks(task, context) {
    const orchestrateTask = {
      ...task,
      prompt: `Orchestrai seguenti task:
${JSON.stringify(task.tasks, null, 2)}

Agenti disponibili: ${task.availableAgents?.join(', ') || 'TradingAgent, NFTAgent, WorkflowAgent'}
Priorità: ${task.priority || 'balanced'}
Deadline: ${task.deadline || 'nessuna'}

Crea un piano di esecuzione che:
1. Assegna ogni task all'agente più adatto
2. Identifica dipendenze tra task
3. Ottimizza ordine di esecuzione
4. Gestisce fallback in caso di errori

Output JSON con:
- executionPlan: [{ taskId, agent, order, dependencies, estimatedTime }]
- parallelGroups: [[taskIds che possono eseguire in parallelo]]
- criticalPath: [taskIds nel percorso critico]`
    };

    return super.processTask(orchestrateTask, context);
  }

  // Gestione automazioni
  addAutomation(automation) {
    this.automations.push({
      ...automation,
      id: `auto_${Date.now()}`,
      createdAt: Date.now(),
      enabled: true,
      executions: 0
    });
  }

  getActiveAutomations() {
    return this.automations.filter(a => a.enabled);
  }
}

// ================================================
// SYSTEM AGENT - Monitoraggio e self-healing
// ================================================
class SystemAgent extends SelfLearningAgent {
  constructor(aiProvider, options = {}) {
    super('SystemAgent', aiProvider, {
      ...options,
      memoryLimit: 200,
      improvementCycle: 10
    });

    this.systemHealth = {
      components: new Map(),
      alerts: [],
      repairs: []
    };
  }

  getSystemPrompt() {
    return `Sei SystemAgent di Gene1799 Art Corporation.
Sei responsabile del monitoraggio e manutenzione dell'intero sistema.
Competenze:
- Health monitoring di tutti i componenti
- Diagnosi automatica problemi
- Self-healing e riparazione automatica
- Performance optimization
- Alert e notifiche

Componenti monitorati: ${this.systemHealth.components.size}
Alert attivi: ${this.systemHealth.alerts.filter(a => !a.resolved).length}
Riparazioni effettuate: ${this.systemHealth.repairs.length}

Mantieni sempre il sistema stabile e performante.`;
  }

  async checkSystemHealth() {
    const healthReport = {
      timestamp: Date.now(),
      components: {},
      issues: [],
      recommendations: []
    };

    for (const [name, component] of this.systemHealth.components) {
      try {
        const status = await this.checkComponent(component);
        healthReport.components[name] = status;
        
        if (status.status !== 'healthy') {
          healthReport.issues.push({
            component: name,
            issue: status.issue,
            severity: status.severity
          });
        }
      } catch (error) {
        healthReport.components[name] = {
          status: 'error',
          error: error.message
        };
        healthReport.issues.push({
          component: name,
          issue: error.message,
          severity: 'critical'
        });
      }
    }

    // Se ci sono issues, chiedi all'AI raccomandazioni
    if (healthReport.issues.length > 0) {
      const recommendations = await this.getRepairRecommendations(healthReport.issues);
      healthReport.recommendations = recommendations;
    }

    return healthReport;
  }

  async checkComponent(component) {
    // Override per check specifici
    return { status: 'healthy' };
  }

  async getRepairRecommendations(issues) {
    const task = {
      type: 'complex-analysis',
      prompt: `Analizza questi problemi di sistema e suggerisci riparazioni:
${JSON.stringify(issues, null, 2)}

Per ogni problema:
1. Identifica la causa root
2. Suggerisci fix immediato
3. Suggerisci prevenzione futura
4. Stima impatto se non risolto`
    };

    const response = await this.execute(task);
    return response.content;
  }

  registerComponent(name, config) {
    this.systemHealth.components.set(name, {
      name,
      ...config,
      registeredAt: Date.now()
    });
  }

  addAlert(alert) {
    this.systemHealth.alerts.push({
      ...alert,
      id: `alert_${Date.now()}`,
      createdAt: Date.now(),
      resolved: false
    });
  }

  resolveAlert(alertId) {
    const alert = this.systemHealth.alerts.find(a => a.id === alertId);
    if (alert) {
      alert.resolved = true;
      alert.resolvedAt = Date.now();
    }
  }

  recordRepair(repair) {
    this.systemHealth.repairs.push({
      ...repair,
      timestamp: Date.now()
    });
  }
}

module.exports = {
  SelfLearningAgent,
  TradingAgent,
  NFTAgent,
  WorkflowAgent,
  SystemAgent
};
