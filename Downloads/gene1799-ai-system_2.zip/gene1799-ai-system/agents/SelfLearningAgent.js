/**
 * GENE1799 Self-Learning Agent Base
 * Classe base per agenti AI auto-imparanti
 */

const EventEmitter = require('events');
const fs = require('fs').promises;
const path = require('path');

class SelfLearningAgent extends EventEmitter {
  constructor(name, aiProvider, options = {}) {
    super();
    this.name = name;
    this.ai = aiProvider;
    this.options = options;
    
    // Stato agente
    this.state = {
      status: 'idle',
      lastAction: null,
      performance: {
        tasksCompleted: 0,
        successRate: 100,
        avgResponseTime: 0
      }
    };

    // Memoria e apprendimento
    this.memory = {
      shortTerm: [],      // Ultime N interazioni
      longTerm: new Map(), // Patterns appresi
      feedback: []         // Feedback ricevuti
    };
    this.memoryLimit = options.memoryLimit || 100;

    // Knowledge base
    this.knowledge = new Map();
    
    // Configurazione apprendimento
    this.learningConfig = {
      enabled: options.learning !== false,
      adaptThreshold: options.adaptThreshold || 0.7,
      learnFromMistakes: true,
      improvementCycle: options.improvementCycle || 50
    };

    this.dataPath = path.join(process.cwd(), 'data', 'agents', name);
    
    console.log(`[Agent:${name}] Inizializzato`);
  }

  // === CICLO DI VITA ===

  async initialize() {
    await this.loadState();
    this.state.status = 'ready';
    this.emit('ready', { agent: this.name });
    return this;
  }

  async shutdown() {
    await this.saveState();
    this.state.status = 'stopped';
    this.emit('shutdown', { agent: this.name });
  }

  // === ESECUZIONE TASK ===

  async execute(task) {
    const startTime = Date.now();
    this.state.status = 'working';
    this.state.lastAction = task.type;

    try {
      // Pre-processo con memoria
      const context = this.buildContext(task);
      
      // Chiama AI
      const response = await this.processTask(task, context);
      
      // Post-processo e apprendimento
      const result = await this.postProcess(task, response);
      
      // Aggiorna statistiche
      this.updateStats(true, Date.now() - startTime);
      
      // Salva in memoria
      this.remember({
        task,
        result,
        success: true,
        timestamp: Date.now()
      });

      this.state.status = 'idle';
      this.emit('taskComplete', { agent: this.name, task, result });
      
      return result;

    } catch (error) {
      this.updateStats(false, Date.now() - startTime);
      this.state.status = 'error';
      
      // Impara dall'errore
      if (this.learningConfig.learnFromMistakes) {
        this.learnFromError(task, error);
      }

      this.emit('taskError', { agent: this.name, task, error });
      throw error;
    }
  }

  // Override questo metodo nelle sottoclassi
  async processTask(task, context) {
    const prompt = this.buildPrompt(task, context);
    return await this.ai.query(task.type || 'quick-response', prompt, {
      systemPrompt: this.getSystemPrompt(),
      temperature: task.temperature || 0.7
    });
  }

  buildPrompt(task, context) {
    let prompt = task.prompt || JSON.stringify(task);
    
    // Aggiungi contesto dalla memoria
    if (context.relevantMemories.length > 0) {
      prompt = `Contesto da interazioni precedenti:\n${
        context.relevantMemories.map(m => `- ${m.summary}`).join('\n')
      }\n\nTask corrente:\n${prompt}`;
    }

    // Aggiungi knowledge rilevante
    if (context.knowledge.length > 0) {
      prompt += `\n\nConoscenze rilevanti:\n${context.knowledge.join('\n')}`;
    }

    return prompt;
  }

  getSystemPrompt() {
    return `Sei ${this.name}, un agente AI di Gene1799 Art Corporation.
Il tuo obiettivo è completare i task assegnati nel modo più efficace possibile.
Impara da ogni interazione per migliorare continuamente.`;
  }

  async postProcess(task, response) {
    // Override per elaborazione specifica
    return {
      content: response.content,
      provider: response.provider,
      model: response.model,
      latency: response.latency,
      processed: true
    };
  }

  // === MEMORIA E CONTESTO ===

  buildContext(task) {
    return {
      relevantMemories: this.recallRelevant(task),
      knowledge: this.getRelevantKnowledge(task),
      previousActions: this.memory.shortTerm.slice(-5)
    };
  }

  remember(interaction) {
    // Short term memory (FIFO)
    this.memory.shortTerm.push({
      ...interaction,
      summary: this.summarizeInteraction(interaction)
    });

    if (this.memory.shortTerm.length > this.memoryLimit) {
      const removed = this.memory.shortTerm.shift();
      // Consolida in long term se importante
      if (this.isImportant(removed)) {
        this.consolidateMemory(removed);
      }
    }

    // Trigger apprendimento periodico
    if (this.memory.shortTerm.length % this.learningConfig.improvementCycle === 0) {
      this.analyzeAndImprove();
    }
  }

  summarizeInteraction(interaction) {
    const { task, result, success } = interaction;
    return `[${success ? '✓' : '✗'}] ${task.type}: ${
      result?.content?.substring(0, 100) || 'N/A'
    }...`;
  }

  recallRelevant(task) {
    // Trova memorie rilevanti per il task corrente
    const keywords = this.extractKeywords(task);
    
    return this.memory.shortTerm
      .filter(m => {
        const memKeywords = this.extractKeywords(m.task);
        return keywords.some(k => memKeywords.includes(k));
      })
      .slice(-5); // Ultime 5 rilevanti
  }

  extractKeywords(obj) {
    const text = JSON.stringify(obj).toLowerCase();
    // Estrai parole significative (>3 caratteri)
    return text.match(/\b[a-z]{4,}\b/g) || [];
  }

  isImportant(memory) {
    // Criteri per memoria importante
    return memory.success === false || // Errori
           memory.task.priority === 'high' ||
           memory.result?.insights; // Ha generato insights
  }

  consolidateMemory(memory) {
    const key = `${memory.task.type}_${Date.now()}`;
    this.memory.longTerm.set(key, {
      pattern: memory.task,
      outcome: memory.success,
      learnings: this.extractLearnings(memory)
    });
  }

  extractLearnings(memory) {
    // Override per estrazione specifica
    return {
      taskType: memory.task.type,
      approach: memory.success ? 'effective' : 'needs-improvement',
      timestamp: memory.timestamp
    };
  }

  // === APPRENDIMENTO ===

  async analyzeAndImprove() {
    console.log(`[Agent:${this.name}] Analisi e miglioramento...`);
    
    const recentMemories = this.memory.shortTerm.slice(-this.learningConfig.improvementCycle);
    
    // Calcola success rate recente
    const recentSuccess = recentMemories.filter(m => m.success).length / recentMemories.length;
    
    if (recentSuccess < this.learningConfig.adaptThreshold) {
      // Performance sotto soglia, analizza errori
      const errors = recentMemories.filter(m => !m.success);
      await this.adaptStrategy(errors);
    }

    // Identifica patterns di successo
    const successPatterns = this.identifyPatterns(
      recentMemories.filter(m => m.success)
    );

    // Salva patterns come knowledge
    successPatterns.forEach(pattern => {
      this.knowledge.set(pattern.key, pattern);
    });

    this.emit('improved', { 
      agent: this.name, 
      successRate: recentSuccess,
      patternsLearned: successPatterns.length 
    });
  }

  identifyPatterns(memories) {
    // Raggruppa per tipo di task
    const grouped = {};
    memories.forEach(m => {
      const type = m.task.type || 'general';
      if (!grouped[type]) grouped[type] = [];
      grouped[type].push(m);
    });

    // Estrai patterns comuni
    return Object.entries(grouped)
      .filter(([_, mems]) => mems.length >= 3)
      .map(([type, mems]) => ({
        key: `pattern_${type}`,
        taskType: type,
        avgLatency: mems.reduce((a, m) => a + (m.result?.latency || 0), 0) / mems.length,
        commonKeywords: this.findCommonKeywords(mems),
        successFactors: this.analyzeSuccessFactors(mems)
      }));
  }

  findCommonKeywords(memories) {
    const allKeywords = memories.flatMap(m => this.extractKeywords(m.task));
    const counts = {};
    allKeywords.forEach(k => counts[k] = (counts[k] || 0) + 1);
    
    return Object.entries(counts)
      .filter(([_, count]) => count >= memories.length * 0.5)
      .map(([keyword]) => keyword);
  }

  analyzeSuccessFactors(memories) {
    // Override per analisi specifica
    return {
      avgPromptLength: memories.reduce((a, m) => 
        a + (m.task.prompt?.length || 0), 0) / memories.length,
      commonProvider: this.mostCommon(memories.map(m => m.result?.provider))
    };
  }

  mostCommon(arr) {
    const counts = {};
    arr.forEach(item => counts[item] = (counts[item] || 0) + 1);
    return Object.entries(counts).sort((a, b) => b[1] - a[1])[0]?.[0];
  }

  async adaptStrategy(errors) {
    console.log(`[Agent:${this.name}] Adattamento strategia dopo ${errors.length} errori`);
    
    // Analizza tipi di errore comuni
    const errorTypes = {};
    errors.forEach(e => {
      const type = e.error?.type || 'unknown';
      errorTypes[type] = (errorTypes[type] || 0) + 1;
    });

    // Salva come anti-pattern
    this.knowledge.set('anti_patterns', {
      errorTypes,
      avoidStrategies: Object.keys(errorTypes),
      lastUpdated: Date.now()
    });
  }

  learnFromError(task, error) {
    this.memory.feedback.push({
      task,
      error: error.message,
      timestamp: Date.now(),
      type: 'error'
    });
  }

  getRelevantKnowledge(task) {
    const taskType = task.type || 'general';
    const relevant = [];

    // Pattern per questo tipo di task
    const pattern = this.knowledge.get(`pattern_${taskType}`);
    if (pattern) {
      relevant.push(`Best practices per ${taskType}: ${JSON.stringify(pattern.successFactors)}`);
    }

    // Anti-patterns da evitare
    const antiPatterns = this.knowledge.get('anti_patterns');
    if (antiPatterns) {
      relevant.push(`Da evitare: ${antiPatterns.avoidStrategies.join(', ')}`);
    }

    return relevant;
  }

  // === FEEDBACK ESTERNO ===

  receiveFeedback(feedback) {
    this.memory.feedback.push({
      ...feedback,
      timestamp: Date.now()
    });

    // Se feedback negativo, impara immediatamente
    if (feedback.rating < 0.5) {
      this.learnFromError(feedback.task, { message: feedback.comment });
    }

    this.emit('feedbackReceived', { agent: this.name, feedback });
  }

  // === STATISTICHE ===

  updateStats(success, responseTime) {
    const perf = this.state.performance;
    perf.tasksCompleted++;
    
    // Running average
    perf.avgResponseTime = (perf.avgResponseTime * (perf.tasksCompleted - 1) + responseTime) 
                           / perf.tasksCompleted;
    
    // Success rate
    const totalSuccess = Math.round(perf.successRate * (perf.tasksCompleted - 1) / 100);
    perf.successRate = Math.round(((totalSuccess + (success ? 1 : 0)) / perf.tasksCompleted) * 100);
  }

  getStats() {
    return {
      name: this.name,
      status: this.state.status,
      performance: this.state.performance,
      memorySize: {
        shortTerm: this.memory.shortTerm.length,
        longTerm: this.memory.longTerm.size,
        knowledge: this.knowledge.size
      },
      lastAction: this.state.lastAction
    };
  }

  // === PERSISTENZA ===

  async saveState() {
    try {
      await fs.mkdir(this.dataPath, { recursive: true });
      
      const state = {
        name: this.name,
        state: this.state,
        memory: {
          shortTerm: this.memory.shortTerm.slice(-50), // Ultime 50
          longTerm: [...this.memory.longTerm.entries()],
          feedback: this.memory.feedback.slice(-100)
        },
        knowledge: [...this.knowledge.entries()],
        savedAt: Date.now()
      };

      await fs.writeFile(
        path.join(this.dataPath, 'state.json'),
        JSON.stringify(state, null, 2)
      );

      console.log(`[Agent:${this.name}] Stato salvato`);
    } catch (error) {
      console.error(`[Agent:${this.name}] Errore salvataggio:`, error.message);
    }
  }

  async loadState() {
    try {
      const data = await fs.readFile(
        path.join(this.dataPath, 'state.json'),
        'utf-8'
      );
      
      const saved = JSON.parse(data);
      
      this.state = saved.state;
      this.memory.shortTerm = saved.memory.shortTerm || [];
      this.memory.longTerm = new Map(saved.memory.longTerm || []);
      this.memory.feedback = saved.memory.feedback || [];
      this.knowledge = new Map(saved.knowledge || []);

      console.log(`[Agent:${this.name}] Stato caricato (${this.memory.shortTerm.length} memorie)`);
    } catch (error) {
      console.log(`[Agent:${this.name}] Nessuno stato precedente, inizializzazione pulita`);
    }
  }
}

module.exports = SelfLearningAgent;
