/**
 * GENE1799 Agent Test Script
 * Test rapido per verificare funzionamento agenti
 */

const { AgentManager, getInstance } = require('../core/AgentManager');

async function runTests() {
  console.log('\n╔════════════════════════════════════════════════════════════════╗');
  console.log('║   GENE1799 AI SYSTEM - TEST SUITE                              ║');
  console.log('╚════════════════════════════════════════════════════════════════╝\n');

  // Inizializza
  console.log('[TEST] Inizializzazione AgentManager...');
  const manager = getInstance();
  
  try {
    await manager.initialize();
    console.log('[✓] AgentManager inizializzato\n');
  } catch (error) {
    console.error('[✗] Errore inizializzazione:', error.message);
    console.log('\n[INFO] Verifica che Ollama sia in esecuzione o configura API keys.\n');
    process.exit(1);
  }

  // Test 1: Status
  console.log('[TEST] Verifica status sistema...');
  const status = manager.getStatus();
  console.log(`  - Agenti attivi: ${Object.keys(status.agents).length}`);
  console.log(`  - Provider AI: ${status.providers.map(p => `${p.name}(${p.status})`).join(', ')}`);
  console.log('[✓] Status OK\n');

  // Test 2: Query Trading Agent (se Ollama disponibile)
  console.log('[TEST] Query Trading Agent...');
  try {
    const tradingResult = await manager.query('trading', 'Analizza brevemente BTC', { 
      maxTokens: 100 
    });
    console.log(`  - Provider: ${tradingResult.provider}`);
    console.log(`  - Latency: ${tradingResult.latency}ms`);
    console.log(`  - Response: ${tradingResult.content.substring(0, 100)}...`);
    console.log('[✓] Trading Agent OK\n');
  } catch (error) {
    console.log(`[⚠] Trading Agent: ${error.message}`);
    console.log('    (Normale se nessun provider AI disponibile)\n');
  }

  // Test 3: Query NFT Agent
  console.log('[TEST] Query NFT Agent...');
  try {
    const nftResult = await manager.query('nft', 'Genera un concept per NFT cyberpunk', {
      maxTokens: 100
    });
    console.log(`  - Provider: ${nftResult.provider}`);
    console.log(`  - Response: ${nftResult.content.substring(0, 100)}...`);
    console.log('[✓] NFT Agent OK\n');
  } catch (error) {
    console.log(`[⚠] NFT Agent: ${error.message}\n`);
  }

  // Test 4: Submit Task
  console.log('[TEST] Submit task async...');
  const taskId = await manager.submitTask({
    type: 'workflow',
    prompt: 'Test task',
    priority: 'low'
  });
  console.log(`  - Task ID: ${taskId}`);
  console.log('[✓] Task submission OK\n');

  // Risultato finale
  console.log('════════════════════════════════════════════════════════════════');
  console.log('  TEST COMPLETATI');
  console.log('════════════════════════════════════════════════════════════════\n');

  // Shutdown
  await manager.shutdown();
  process.exit(0);
}

runTests().catch(console.error);
