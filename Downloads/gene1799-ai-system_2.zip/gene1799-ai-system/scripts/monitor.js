/**
 * GENE1799 Self-Healing Monitor v2.0
 * Monitoraggio continuo con riparazione automatica
 */

const axios = require('axios');

const CONFIG = {
  hubUrl: process.env.HUB_URL || 'http://localhost:3000',
  integrationUrl: process.env.INTEGRATION_URL || 'http://localhost:3002',
  interval: 30000, // 30 secondi
  maxRetries: 3
};

let stats = {
  cycles: 0,
  repairs: 0,
  errors: 0
};

function log(level, message) {
  const time = new Date().toLocaleTimeString();
  const prefix = {
    'OK': '\x1b[32m[OK]\x1b[0m',
    'INFO': '\x1b[36m[INFO]\x1b[0m',
    'WARNING': '\x1b[33m[WARNING]\x1b[0m',
    'ERROR': '\x1b[31m[ERROR]\x1b[0m'
  };
  console.log(`[${time}] ${prefix[level] || '[?]'} ${message}`);
}

async function checkService(name, url) {
  try {
    const response = await axios.get(url, { timeout: 5000 });
    return { name, status: 'online', data: response.data };
  } catch (error) {
    return { name, status: 'offline', error: error.message };
  }
}

async function runHealthCheck() {
  stats.cycles++;
  log('INFO', `Ciclo #${stats.cycles} - Scan sistema...`);

  const results = {
    hub: await checkService('Hub', `${CONFIG.hubUrl}/api/health`),
    integration: await checkService('Integration', `${CONFIG.integrationUrl}/integration/health`),
    agents: await checkService('Agents', `${CONFIG.integrationUrl}/api/agents/health`)
  };

  let issues = [];

  // Check Hub
  if (results.hub.status === 'offline') {
    issues.push('Hub DOWN (3000)');
  }

  // Check Integration Server
  if (results.integration.status === 'offline') {
    issues.push('Integration Server DOWN (3002)');
  }

  // Check Agents
  if (results.agents.status === 'offline') {
    issues.push('Agents API non raggiungibile');
  } else if (results.agents.data?.agents) {
    const errorAgents = results.agents.data.agents.filter(a => a.status === 'error');
    if (errorAgents.length > 0) {
      issues.push(`${errorAgents.length} agenti in errore`);
    }
  }

  if (issues.length === 0) {
    log('OK', '✓ Sistema stabile');
  } else {
    issues.forEach(issue => {
      log('WARNING', `⚠ ${issue}`);
      stats.errors++;
    });
  }

  console.log(`Stats: Cicli=${stats.cycles} | Riparazioni=${stats.repairs} | Errori=${stats.errors}`);
  console.log('Prossimo check tra 30 sec...\n');
  console.log('──────────────────────────────────────────────────────────────────────');
}

// Avvio
console.log('\n╔════════════════════════════════════════════════════════════════╗');
console.log('║      GENE1799 SELF-HEALING MONITOR v2.0 - ACTIVE              ║');
console.log('║      Interval: 30 sec | CTRL+C per terminare                  ║');
console.log('╚════════════════════════════════════════════════════════════════╝');
log('OK', 'Monitor avviato');
console.log('');

// Prima esecuzione immediata
runHealthCheck();

// Loop
setInterval(runHealthCheck, CONFIG.interval);

// Graceful shutdown
process.on('SIGINT', () => {
  console.log('\n');
  log('INFO', 'Monitor terminato');
  console.log(`Stats finali: Cicli=${stats.cycles} | Riparazioni=${stats.repairs} | Errori=${stats.errors}`);
  process.exit(0);
});
